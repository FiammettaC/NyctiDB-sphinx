Model library
=========

Elements
----------

Exciting documentation in here.
Let's make a list (empty surrounding lines required):

- Why
- Parameters
- Process conditions

  - Configuration
  - Mode of operation
  - Oxygen conditions
  - Temperature
  - pH
  - Product
  - Limiting substrate
  - Processes involved
  - Type of microorganisms
  - Filamentous growth 

- Type of model
- Literature reference
----------

Example
----------



