Python
=========

Brief introduction to the theory 
----------

----------


----------

Example
------------------------------------------
.. literalinclude:: scripts/script_CGlutamicum.py

----------

A step further
----------
If you want to improve your pure Python programming abilities in a relaxing and challenging way, I recommend you `Python Challenge 
<http://www.pythonchallenge.com/>`_. This webpage has a series of an increasingly difficult challenges to solve thinking as a coder on Python.
GOOD LUCK!